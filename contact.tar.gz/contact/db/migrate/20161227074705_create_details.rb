class CreateDetails < ActiveRecord::Migration
  def self.up
    create_table :details do |t|
    	t.string :first_name
    	t.string :last_name
    	t.string :mobile_no
    	t.string :landline
    	t.string :personal_email
    	t.string :work_email
    	t.string :image_url
    	t.string :github_id
    	t.string :facebook_id


      t.timestamps
    end
  end
end
