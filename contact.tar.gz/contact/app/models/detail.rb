class Detail < ActiveRecord::Base
	validates :first_name, :presence => true
	validates :mobile_no, :presence =>true,
	          :numericality => true,
	          :length => { :minimum =>10, :maximum=>10}
	validates :mobile_no, :allow_blank =>true,
	          :numericality => true,
	          :length => { :minimum =>10, :maximum=>10}
	
    validates :personal_email, format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i, on: :create }
	validates :work_email, format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i, on: :create }

	
	
end
